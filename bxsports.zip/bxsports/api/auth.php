<?php
session_start();
require_once 'config.php';

$accion = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($accion) {

    // ─────────────────────────────────────────
    // INICIO DE SESIÓN
    // ─────────────────────────────────────────
    case 'login':
        $email      = trim($_POST['email'] ?? '');
        $contrasena = $_POST['password'] ?? '';

        if (!$email || !$contrasena) {
            echo json_encode(['ok' => false, 'error' => 'Completa todos los campos.']);
            exit;
        }

        try {
            $bd      = obtenerConexion();
            $stmt    = $bd->query("SELECT u.*, n.nombre AS nivel_nombre FROM usuarios u LEFT JOIN niveles n ON u.nivel_id = n.id WHERE u.email = '$email' LIMIT 1");
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            // Verificar si el usuario existe y la contraseña es correcta
            if (!$usuario || !password_verify($contrasena, $usuario['password'])) {
                echo json_encode(['ok' => false, 'error' => 'Email o contraseña incorrectos.']);
                exit;
            }

            // Guardar datos básicos en la sesión del servidor
            $_SESSION['bx_id']     = $usuario['id'];
            $_SESSION['bx_nombre'] = $usuario['nombre'];
            $_SESSION['bx_rol']    = $usuario['rol'];

            // Eliminar la contraseña antes de enviar los datos al cliente
            unset($usuario['password']);
            echo json_encode(['ok' => true, 'usuario' => $usuario]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error de servidor.']);
        }
        break;

    // ─────────────────────────────────────────
    // REGISTRO DE NUEVO USUARIO
    // ─────────────────────────────────────────
    case 'registro':
        $nombre    = trim($_POST['nombre'] ?? '');
        $apellidos = trim($_POST['apellidos'] ?? '');
        $email     = trim($_POST['email'] ?? '');
        $contrasena = $_POST['password'] ?? '';
        $peso      = floatval($_POST['peso'] ?? 0);
        $altura    = intval($_POST['altura'] ?? 0);
        $edad      = intval($_POST['edad'] ?? 0);
        $sexo      = $_POST['sexo'] ?? '';
        $dias      = $_POST['dias_entreno'] ?? '';
        $objetivo  = $_POST['objetivo'] ?? '';

        // Validar que todos los campos estén rellenos
        if (!$nombre || !$apellidos || !$email || !$contrasena || !$peso || !$altura || !$edad || !$sexo || !$dias || !$objetivo) {
            echo json_encode(['ok' => false, 'error' => 'Completa todos los campos.']);
            exit;
        }

        // Validar formato del email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['ok' => false, 'error' => 'Email no válido.']);
            exit;
        }

        try {
            $bd = obtenerConexion();

            // Comprobar si el email ya está registrado
            $comprobacion = $bd->query("SELECT id FROM usuarios WHERE email = '$email' LIMIT 1");
            if ($comprobacion->fetch()) {
                echo json_encode(['ok' => false, 'error' => 'Este email ya está registrado.']);
                exit;
            }

            // Calcular el IMC del usuario
            $alturaEnMetros = $altura / 100;
            $imc            = round($peso / ($alturaEnMetros * $alturaEnMetros), 1);

            // Convertir los días al valor numérico para comparar con la tabla de niveles
            $mapasDias = ['1-2' => 1, '3-4' => 3, '5-6' => 5, '7' => 7];
            $diasNum   = $mapasDias[$dias] ?? 0;

            // Determinar el nivel según IMC y días de entrenamiento
            $nivel_id = calcularNivel($bd, $imc, $diasNum);

            // Hashear la contraseña antes de guardarla
            $hashContrasena = password_hash($contrasena, PASSWORD_DEFAULT);

            // Insertar el nuevo usuario en la base de datos
            $bd->exec("INSERT INTO usuarios (nombre, apellidos, email, password, peso, altura, edad, sexo, dias_entreno, objetivo, rol, nivel_id)
                        VALUES ('$nombre', '$apellidos', '$email', '$hashContrasena', $peso, $altura, $edad, '$sexo', '$dias', '$objetivo', 'usuario', $nivel_id)");

            $nuevoId = $bd->lastInsertId();

            // Insertar el primer check-in automáticamente al registrarse
            $bd->exec("INSERT INTO checkins (usuario_id, peso, altura, imc, nivel_id) VALUES ($nuevoId, $peso, $altura, $imc, $nivel_id)");

            // Guardar sesión del servidor
            $_SESSION['bx_id']     = $nuevoId;
            $_SESSION['bx_nombre'] = $nombre;
            $_SESSION['bx_rol']    = 'usuario';

            // Recuperar el usuario completo con el nombre del nivel
            $stmt    = $bd->query("SELECT u.*, n.nombre AS nivel_nombre FROM usuarios u LEFT JOIN niveles n ON u.nivel_id = n.id WHERE u.id = $nuevoId LIMIT 1");
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            unset($usuario['password']);

            echo json_encode(['ok' => true, 'usuario' => $usuario]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al registrar: ' . $e->getMessage()]);
        }
        break;

    // ─────────────────────────────────────────
    // CIERRE DE SESIÓN
    // ─────────────────────────────────────────
    case 'logout':
        session_destroy();
        echo json_encode(['ok' => true]);
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}

// Calcula el nivel del usuario según su IMC y días de entrenamiento
function calcularNivel($bd, $imc, $diasNum) {
    $stmt = $bd->query("SELECT id FROM niveles WHERE $imc BETWEEN imc_min AND imc_max AND $diasNum BETWEEN dias_min AND dias_max LIMIT 1");
    $fila = $stmt->fetch(PDO::FETCH_ASSOC);
    // Si no hay coincidencia exacta se asigna el nivel 1 (Iniciado)
    return $fila ? $fila['id'] : 1;
}
