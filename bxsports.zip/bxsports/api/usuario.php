<?php
session_start();
require_once 'config.php';

$accion = $_REQUEST['action'] ?? '';

switch ($accion) {

    // Obtener datos del perfil y historial de check-ins
    case 'getPerfil':
        $id = intval($_GET['id'] ?? 0);

        if (!$id) {
            echo json_encode(['ok' => false, 'error' => 'ID no válido.']);
            exit;
        }

        try {
            $bd = obtenerConexion();

            // Obtener datos del usuario con el nombre de su nivel
            $stmt    = $bd->query("SELECT u.*, n.nombre AS nivel_nombre FROM usuarios u LEFT JOIN niveles n ON u.nivel_id = n.id WHERE u.id = $id LIMIT 1");
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$usuario) {
                echo json_encode(['ok' => false, 'error' => 'Usuario no encontrado.']);
                exit;
            }

            unset($usuario['password']);

            // Obtener los últimos 10 check-ins ordenados del más reciente al más antiguo
            $stmt     = $bd->query("SELECT c.*, n.nombre AS nivel_nombre FROM checkins c LEFT JOIN niveles n ON c.nivel_id = n.id WHERE c.usuario_id = $id ORDER BY c.fecha DESC LIMIT 10");
            $checkins = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode(['ok' => true, 'usuario' => $usuario, 'checkins' => $checkins]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al obtener perfil.']);
        }
        break;

    // Actualizar datos 
    case 'updatePerfil':
        $id       = intval($_POST['id'] ?? 0);
        $peso     = floatval($_POST['peso'] ?? 0);
        $altura   = intval($_POST['altura'] ?? 0);
        $edad     = intval($_POST['edad'] ?? 0);
        $objetivo = $_POST['objetivo'] ?? '';
        $dias     = $_POST['dias_entreno'] ?? '';

        if (!$id || !$peso || !$altura || !$edad || !$objetivo || !$dias) {
            echo json_encode(['ok' => false, 'error' => 'Completa todos los campos.']);
            exit;
        }

        try {
            $bd = obtenerConexion();

            // Recalcular IMC y nivel con los nuevos datos
            $alturaEnMetros = $altura / 100;
            $imc            = round($peso / ($alturaEnMetros * $alturaEnMetros), 1);
            $mapasDias      = ['1-2' => 1, '3-4' => 3, '5-6' => 5, '7' => 7];
            $diasNum        = $mapasDias[$dias] ?? 0;

            $stmt     = $bd->query("SELECT id FROM niveles WHERE $imc BETWEEN imc_min AND imc_max AND $diasNum BETWEEN dias_min AND dias_max LIMIT 1");
            $filaivel = $stmt->fetch(PDO::FETCH_ASSOC);
            $nivel_id = $filaivel ? $filaivel['id'] : 1;

            // Actualizar los datos del usuario en la base de dato
            $bd->exec("UPDATE usuarios SET peso=$peso, altura=$altura, edad=$edad, objetivo='$objetivo', dias_entreno='$dias', nivel_id=$nivel_id WHERE id=$id");

            // Insertar nuevo check-in con los datos actualizados
            $bd->exec("INSERT INTO checkins (usuario_id, peso, altura, imc, nivel_id) VALUES ($id, $peso, $altura, $imc, $nivel_id)");

            // Devolver el usuario actualizado con el nombre del nivel
            $stmt    = $bd->query("SELECT u.*, n.nombre AS nivel_nombre FROM usuarios u LEFT JOIN niveles n ON u.nivel_id = n.id WHERE u.id = $id LIMIT 1");
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            unset($usuario['password']);

            echo json_encode(['ok' => true, 'usuario' => $usuario]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al actualizar perfil.']);
        }
        break;

    // Subir foto de perfil
    case 'subirFoto':
        $id = intval($_POST['id'] ?? 0);

        if (!$id || !isset($_FILES['foto'])) {
            echo json_encode(['ok' => false, 'error' => 'Datos incompletos.']);
            exit;
        }

        $archivo          = $_FILES['foto'];
        $extension        = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        $formatosPermitidos = ['jpg', 'jpeg', 'png', 'webp'];


        $directorio = '../uploads/avatars/';
        if (!is_dir($directorio)) mkdir($directorio, 0755, true);

        $nombreArchivo = 'avatar_' . $id . '.' . $extension;
        $rutaCompleta  = $directorio . $nombreArchivo;

        // Mover el archivo a la carpeta de avatares
        if (!move_uploaded_file($archivo['tmp_name'], $rutaCompleta)) {
            echo json_encode(['ok' => false, 'error' => 'Error al subir la imagen.']);
            exit;
        }

        try {
            $bd      = obtenerConexion();
            $urlFoto = 'uploads/avatars/' . $nombreArchivo;
            $bd->exec("UPDATE usuarios SET foto='$urlFoto' WHERE id=$id");
            echo json_encode(['ok' => true, 'foto' => $urlFoto]);
        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al guardar foto.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
