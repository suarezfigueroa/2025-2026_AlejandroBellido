<?php
session_start();
require_once 'config.php';

$accion = $_POST['action'] ?? '';

switch ($accion) {

    // Cambiar la contraseña del usuario
    case 'cambiarPassword':
        $id         = intval($_POST['id'] ?? 0);
        $actual     = $_POST['actual'] ?? '';
        $nueva      = $_POST['nueva'] ?? '';
        $confirmar  = $_POST['confirmar'] ?? '';

        if (!$id || !$actual || !$nueva || !$confirmar) {
            echo json_encode(['ok' => false, 'error' => 'Completa todos los campos.']);
            exit;
        }

        try {
            $bd   = obtenerConexion();
            $stmt = $bd->query("SELECT password FROM usuarios WHERE id=$id LIMIT 1");
            $fila = $stmt->fetch(PDO::FETCH_ASSOC);

            // Verificar que la contraseña actual es correcta
            if (!$fila || !password_verify($actual, $fila['password'])) {
                echo json_encode(['ok' => false, 'error' => 'La contraseña actual es incorrecta.']);
                exit;
            }

            // Hashear la nueva contraseña y guardarla
            $hashNueva = password_hash($nueva, PASSWORD_DEFAULT);
            $bd->exec("UPDATE usuarios SET password='$hashNueva' WHERE id=$id");

            echo json_encode(['ok' => true, 'msg' => 'Contraseña actualizada correctamente.']);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al cambiar la contraseña.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
