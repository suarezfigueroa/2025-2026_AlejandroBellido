<?php
session_start();
require_once 'config.php';

$accion = $_GET['action'] ?? '';

switch ($accion) {

    // Obtener ejercicios filtrados por nivel, día y categoría
    case 'getEjercicios':
        $nivel_id  = intval($_GET['nivel_id'] ?? 1);
        $dia       = $_GET['dia'] ?? '';
        $categoria = $_GET['categoria'] ?? '';

        try {
            $bd  = obtenerConexion();
            $sql = "SELECT * FROM ejercicios WHERE nivel_id = $nivel_id";

            // Filtrar por día si se especifica
            if ($dia) {
                $sql .= " AND dia = '$dia'";
            }

            // Filtrar por categoría si se especifica y no es "Todos"
            if ($categoria && $categoria !== 'Todos') {
                $sql .= " AND categoria = '$categoria'";
            }

            $sql .= " ORDER BY grupo_muscular, nombre";

            $stmt      = $bd->query($sql);
            $ejercicios = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode(['ok' => true, 'ejercicios' => $ejercicios]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al obtener ejercicios.']);
        }
        break;

    // Obtener el detalle de un ejercicio concreto
    case 'getEjercicio':
        $id = intval($_GET['id'] ?? 0);

        if (!$id) {
            echo json_encode(['ok' => false, 'error' => 'ID no válido.']);
            exit;
        }

        try {
            $bd   = obtenerConexion();
            $stmt = $bd->query("SELECT e.*, n.nombre AS nivel_nombre FROM ejercicios e LEFT JOIN niveles n ON e.nivel_id = n.id WHERE e.id = $id LIMIT 1");
            $fila = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$fila) {
                echo json_encode(['ok' => false, 'error' => 'Ejercicio no encontrado.']);
                exit;
            }

            echo json_encode(['ok' => true, 'ejercicio' => $fila]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al obtener ejercicio.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
