<?php
session_start();
require_once 'config.php';

$accion = $_REQUEST['action'] ?? '';

switch ($accion) {

    // Obtener todos los usuarios registrados
    case 'getUsuarios':
        try {
            $bd   = obtenerConexion();
            $stmt = $bd->query("SELECT u.id, u.nombre, u.apellidos, u.email, u.peso, u.altura, u.edad, u.sexo, u.dias_entreno, u.objetivo, u.rol, u.created_at, n.nombre AS nivel_nombre FROM usuarios u LEFT JOIN niveles n ON u.nivel_id = n.id ORDER BY u.created_at DESC");
            $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok' => true, 'usuarios' => $filas]);
        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al obtener usuarios.']);
        }
        break;

    // Eliminar un usuario y sus check-ins 
    case 'borrarUsuario':
        $id = intval($_POST['id'] ?? 0);
        if (!$id) {
            echo json_encode(['ok' => false, 'error' => 'ID no válido.']);
            exit;
        }
        try {
            $bd = obtenerConexion();
            // Primero borrar los check-ins para no estropear la clave foránea
            $bd->exec("DELETE FROM checkins WHERE usuario_id = $id");
            // para que no pueda borrar a un admin
            $bd->exec("DELETE FROM usuarios WHERE id = $id AND rol != 'admin'");
            echo json_encode(['ok' => true]);
        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al borrar usuario.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
