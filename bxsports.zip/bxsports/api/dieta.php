<?php
session_start();
require_once 'config.php';

$accion = $_GET['action'] ?? '';

switch ($accion) {

    // Obtener las comidas filtradas por nivel y objetivo
    case 'getComidas':
        $nivel_id = intval($_GET['nivel_id'] ?? 1);
        $objetivo = $_GET['objetivo'] ?? '';

        if (!$objetivo) {
            echo json_encode(['ok' => false, 'error' => 'Objetivo no especificado.']);
            exit;
        }

        try {
            $bd  = obtenerConexion();
            // ordena las comidas en el orden lógico del día
            $sql = "SELECT * FROM dieta
                    WHERE nivel_id = $nivel_id
                    AND objetivo = '$objetivo'
                    ORDER BY FIELD(comida, 'Desayuno','Almuerzo','Comida','Merienda','Cena','Recena')";

            $stmt   = $bd->query($sql);
            $comidas = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode(['ok' => true, 'comidas' => $comidas]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al obtener dieta.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
