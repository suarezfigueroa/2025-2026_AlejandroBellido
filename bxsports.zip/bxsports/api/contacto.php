<?php
session_start();
require_once 'config.php';

$accion = $_POST['action'] ?? '';

switch ($accion) {

    // Guardar un mensaje del formulario 
    case 'enviarContacto':
        $nombre  = trim($_POST['nombre']  ?? '');
        $email   = trim($_POST['email']   ?? '');
        $asunto  = trim($_POST['asunto']  ?? '');
        $mensaje = trim($_POST['mensaje'] ?? '');

        // Validar que todos los campos esten rellenos
        if (!$nombre || !$email || !$asunto || !$mensaje) {
            echo json_encode(['ok' => false, 'error' => 'Completa todos los campos.']);
            exit;
        }

        try {
            $bd = obtenerConexion();
            $bd->exec("INSERT INTO contacto (nombre, email, asunto, mensaje)
                        VALUES ('$nombre', '$email', '$asunto', '$mensaje')");

            echo json_encode(['ok' => true, 'msg' => 'Mensaje enviado correctamente. Nos pondremos en contacto contigo pronto.']);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al enviar el mensaje.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
