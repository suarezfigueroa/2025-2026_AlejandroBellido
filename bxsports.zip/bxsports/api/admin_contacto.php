<?php
session_start();
require_once 'config.php';

$accion = $_REQUEST['action'] ?? '';

switch ($accion) {

    // Obtener todos los mensajes del formulario
    case 'getMensajes':
        try {
            $bd   = obtenerConexion();
            $stmt = $bd->query("SELECT * FROM contacto ORDER BY fecha DESC");
            $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok' => true, 'mensajes' => $filas]);
        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al obtener mensajes.']);
        }
        break;

    // Eliminar un mensaje del formulario
    case 'borrarMensaje':
        $id = intval($_POST['id'] ?? 0);
        if (!$id) {
            echo json_encode(['ok' => false, 'error' => 'ID no válido.']);
            exit;
        }
        try {
            $bd = obtenerConexion();
            $bd->exec("DELETE FROM contacto WHERE id = $id");
            echo json_encode(['ok' => true]);
        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al borrar mensaje.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
