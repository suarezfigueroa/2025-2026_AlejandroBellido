<?php

define('BD_HOST',     'localhost');
define('BD_USUARIO',  'root');
define('BD_CONTRASENA', '');
define('BD_NOMBRE',   'bxsports');

function obtenerConexion() {
    $conexion = new PDO(
        'mysql:host=' . BD_HOST . ';dbname=' . BD_NOMBRE . ';charset=utf8mb4',
        BD_USUARIO,
        BD_CONTRASENA
    );
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conexion;
}

// Cabeceras para todas las respuestas de la API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');
