<?php
session_start();
require_once 'config.php';

$accion = $_GET['action'] ?? '';

switch ($accion) {

    // Obtener todos los niveles y el nivel actual del usuario
    case 'getNiveles':
        $usuario_id = intval($_GET['usuario_id'] ?? 0);

        try {
            $bd = obtenerConexion();

            // Obtener los 5 niveles ordenados por ID
            $stmt    = $bd->query("SELECT * FROM niveles ORDER BY id");
            $niveles = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Obtener el nivel actual del usuario si se proporciona su ID
            $nivelActual = null;
            if ($usuario_id) {
                $stmt        = $bd->query("SELECT u.nivel_id, n.nombre AS nivel_nombre FROM usuarios u LEFT JOIN niveles n ON u.nivel_id = n.id WHERE u.id = $usuario_id LIMIT 1");
                $nivelActual = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            echo json_encode([
                'ok'           => true,
                'niveles'      => $niveles,
                'nivel_actual' => $nivelActual
            ]);

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => 'Error al obtener niveles.']);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no reconocida.']);
        break;
}
