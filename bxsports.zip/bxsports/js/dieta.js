
async function initDieta() {
    const usuario = JSON.parse(sessionStorage.getItem('bx_usuario'));

    // Mostrar nivel y objetivo del usuario en el contexto del plan
    const elementoNivel    = document.getElementById('ctx-nivel');
    const elementoObjetivo = document.getElementById('ctx-objetivo');

    if (elementoNivel)    elementoNivel.textContent    = usuario.nivel_nombre || 'Iniciado';
    if (elementoObjetivo) elementoObjetivo.textContent = usuario.objetivo;

    await cargarDieta(usuario.nivel_id, usuario.objetivo);
}

// Solicita las comidas a la API y las pinta en pantalla
async function cargarDieta(nivel_id, objetivo) {
    const grid = document.getElementById('dieta-grid');
    if (!grid) return;

    grid.innerHTML = '<div class="loader">Cargando plan de dieta...</div>';

    const datos = await Api.get('dieta.php', {
        action: 'getComidas',
        nivel_id,
        objetivo
    });

    if (!datos.ok || !datos.comidas.length) {
        grid.innerHTML = '<div class="loader">No hay plan disponible para tu nivel y objetivo.</div>';
        return;
    }

    // Calcular el total de calorías y proteínas del día
    let totalCalorias  = 0;
    let totalProteinas = 0;

    datos.comidas.forEach(comida => {
        totalCalorias  += parseInt(comida.calorias  || 0);
        totalProteinas += parseInt(comida.proteinas || 0);
    });

    // Mostrar los totales en el resumen del plan
    const elementoCal  = document.getElementById('ctx-calorias');
    const elementoProt = document.getElementById('ctx-proteina');
    if (elementoCal)  elementoCal.textContent  = '~' + totalCalorias  + ' kcal';
    if (elementoProt) elementoProt.textContent = '~' + totalProteinas + 'g';

    // Pintar las tarjetas de cada comida
    grid.innerHTML = datos.comidas.map(comida => tarjetaComida(comida)).join('');
}

// Genera el HTML de una tarjeta de comida
function tarjetaComida(comida) {
    // Formatear ingredientes separados por coma como lista visual
    const ingredientes = comida.ingredientes
        ? comida.ingredientes.split(',').map(ing => ing.trim()).join('<br>')
        : '—';

    return `
    <div class="comida-card">
        <div class="comida-header">
            <div class="comida-nombre">${comida.comida}</div>
            <div class="comida-hora">${comida.hora}</div>
        </div>
        <div class="comida-plato">${comida.nombre}</div>
        <div class="comida-ingredientes">${ingredientes}</div>
        <div class="comida-macros">
            <div class="macro">
                <div class="macro-label">KCAL</div>
                <div class="macro-val lime">${comida.calorias}</div>
            </div>
            <div class="macro">
                <div class="macro-label">PROT</div>
                <div class="macro-val white">${comida.proteinas}g</div>
            </div>
            <div class="macro">
                <div class="macro-label">CARB</div>
                <div class="macro-val white">${comida.carbohidratos}g</div>
            </div>
            <div class="macro">
                <div class="macro-label">GRA</div>
                <div class="macro-val white">${comida.grasas}g</div>
            </div>
        </div>
    </div>`;
}
