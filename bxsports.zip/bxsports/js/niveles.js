
async function initNiveles() {
    const usuario = JSON.parse(sessionStorage.getItem('bx_usuario'));

    const datos = await Api.get('niveles.php', {
        action:     'getNiveles',
        usuario_id: usuario.id
    });

    if (!datos.ok) {
        document.getElementById('niveles-grid').innerHTML =
            '<div class="loader">Error al cargar niveles.</div>';
        return;
    }

    // Calcular el IMC del usuario con sus datos actuales
    const alturaEnMetros = usuario.altura / 100;
    const imc            = (usuario.peso / (alturaEnMetros * alturaEnMetros)).toFixed(1);

    // Mostrar el nivel actual y el IMC en el banner superior
    const nivelActual = datos.nivel_actual;
    document.getElementById('banner-nombre').innerHTML =
        `${nivelActual.nivel_nombre} <span>· Nivel ${nivelActual.nivel_id}</span>`;
    document.getElementById('banner-imc').textContent = imc;

    // Pintar el grid con las 5 tarjetas de nivel
    const grid = document.getElementById('niveles-grid');
    grid.innerHTML = datos.niveles.map(nivel => tarjetaNivel(nivel, nivelActual.nivel_id)).join('');

    // Mostrar información del próximo nivel si no es el máximo
    const nivelSiguiente = datos.niveles.find(n => n.id === nivelActual.nivel_id + 1);
    const infoProximo    = document.getElementById('nivel-info');

    if (nivelSiguiente && infoProximo) {
        infoProximo.style.display = 'flex';

        document.getElementById('info-proximo').innerHTML =
            `<span style="color:${nivelSiguiente.color}">${nivelSiguiente.nombre}</span> · Nivel ${nivelSiguiente.id}`;

        document.getElementById('info-condicion').textContent =
            `IMC ${nivelSiguiente.imc_min}–${nivelSiguiente.imc_max} y ${nivelSiguiente.dias_min}–${nivelSiguiente.dias_max} días/sem`;
    }
}

// Genera el HTML de una tarjeta de nivel
function tarjetaNivel(nivel, idNivelActual) {
    const esNivelActual = nivel.id === parseInt(idNivelActual);

    const badge = esNivelActual
        ? `<div class="nivel-badge">TÚ ESTÁS AQUÍ</div>`
        : '';

    return `
    <div class="nivel-card nivel-${nivel.id} ${esNivelActual ? 'actual' : ''}">
        ${badge}
        <img src="icons/nivel${nivel.id}.png" alt="${nivel.nombre}" style="width:60px;height:60px;object-fit:contain;margin:8px auto 6px;display:block">
        <div class="nivel-nombre">${nivel.nombre.toUpperCase()}</div>
        <div class="nivel-divider"></div>
        <div class="nivel-criterios">
            IMC ${nivel.imc_min}–${nivel.imc_max}<br>
            ${nivel.dias_min}–${nivel.dias_max} días/sem
        </div>
    </div>`;
}
