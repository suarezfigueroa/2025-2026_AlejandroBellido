
// Todas las llamadas al servidor pasan por aquí

const BASE = 'api/';

const Api = {

    // Petición POST con FormData
    async post(endpoint, parametros = {}) {
        const formulario = new FormData();
        for (const [clave, valor] of Object.entries(parametros)) {
            formulario.append(clave, valor);
        }
        try {
            const respuesta = await fetch(BASE + endpoint, { method: 'POST', body: formulario });
            const datos     = await respuesta.json();
            return datos;
        } catch (error) {
            return { ok: false, error: 'Error de conexión.' };
        }
    },

    // Petición GET con parámetros en la URL
    async get(endpoint, parametros = {}) {
        const cadenaParams = new URLSearchParams(parametros).toString();
        const url          = BASE + endpoint + (cadenaParams ? '?' + cadenaParams : '');
        try {
            const respuesta = await fetch(url);
            const datos     = await respuesta.json();
            return datos;
        } catch (error) {
            return { ok: false, error: 'Error de conexión.' };
        }
    }
};
