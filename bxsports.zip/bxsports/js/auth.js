const RUTA_AUTH = '../api/auth.php';

// Muestra un mensaje de error en el formulario
function mostrarError(mensaje) {
    const elemento = document.getElementById('error-msg');
    elemento.textContent = mensaje;
    elemento.classList.add('visible');
}

// Oculta el mensaje de error
function ocultarError() {
    const elemento = document.getElementById('error-msg');
    if (elemento) elemento.classList.remove('visible');
}

// Gestiona el inicio de sesión
async function handleLogin() {
    ocultarError();

    const email      = document.getElementById('email').value.trim();
    const contrasena = document.getElementById('password').value;

    if (!email || !contrasena) {
        mostrarError('Completa todos los campos.');
        return;
    }

    const formulario = new FormData();
    formulario.append('action', 'login');
    formulario.append('email', email);
    formulario.append('password', contrasena);

    try {
        const respuesta = await fetch(RUTA_AUTH, { method: 'POST', body: formulario });
        const datos     = await respuesta.json();

        if (datos.ok) {
            // Guardar usuario en la sesión del navegador
            sessionStorage.setItem('bx_usuario', JSON.stringify(datos.usuario));

            // Redirigir según el rol del usuario
            if (datos.usuario.rol === 'admin') {
                window.location.href = '../admin.html';
            } else {
                window.location.href = '../app.html';
            }
        } else {
            mostrarError(datos.error);
        }
    } catch (error) {
        mostrarError('Error de conexión. Comprueba que el servidor está activo.');
    }
}

// Gestiona el registro de un nuevo usuario
async function handleRegistro() {
    ocultarError();

    const campos  = ['nombre','apellidos','email','password','peso','altura','edad','sexo','dias_entreno','objetivo'];
    const valores = {};

    // Recorrer todos los campos y validar que no estén vacíos
    for (const campo of campos) {
        const elemento = document.getElementById(campo);
        if (!elemento) continue;
        valores[campo] = elemento.value.trim();
        if (!valores[campo]) {
            mostrarError('Completa todos los campos.');
            return;
        }
    }

    // Construir el formulario con todos los valores
    const formulario = new FormData();
    formulario.append('action', 'registro');
    for (const [clave, valor] of Object.entries(valores)) {
        formulario.append(clave, valor);
    }

    try {
        const respuesta = await fetch(RUTA_AUTH, { method: 'POST', body: formulario });
        const datos     = await respuesta.json();

        if (datos.ok) {
            sessionStorage.setItem('bx_usuario', JSON.stringify(datos.usuario));
            window.location.href = '../app.html';
        } else {
            mostrarError(datos.error);
        }
    } catch (error) {
        mostrarError('Error de conexión. Comprueba que el servidor está activo.');
    }
}

// Cierra la sesión del usuario
async function handleLogout() {
    const formulario = new FormData();
    formulario.append('action', 'logout');
    try {
        await fetch(RUTA_AUTH, { method: 'POST', body: formulario });
    } catch (error) {}

    sessionStorage.removeItem('bx_usuario');
    window.location.href = 'views/login.html';
}
