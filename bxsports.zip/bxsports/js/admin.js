// Mapa de vistas del panel admin y sus funciones de inicio
const vistasAdmin = {
    admin_usuarios: () => initAdminUsuarios(),
    admin_contacto: () => initAdminContacto(),
    admin_perfil:   () => initAdminPerfil()
};

// Navega entre las secciones del panel admin
async function navigateAdmin(vista) {
    if (!vistasAdmin[vista]) return;

    // Marcar la sección activa en el menú
    document.querySelectorAll('.nav-item').forEach(elemento => {
        elemento.classList.toggle('active', elemento.dataset.view === vista);
    });

    const contenedor = document.getElementById('view');
    contenedor.innerHTML = '<div class="loader">Cargando...</div>';

    try {
        const respuesta = await fetch('views/' + vista + '.html');
        const html      = await respuesta.text();
        contenedor.innerHTML = html;
    } catch (error) {
        contenedor.innerHTML = '<div class="loader">Error al cargar la vista.</div>';
        return;
    }

    vistasAdmin[vista]();
    location.hash = vista;
}

// Punto de arranque del panel admin
document.addEventListener('DOMContentLoaded', () => {
    const sesionGuardada = sessionStorage.getItem('bx_usuario');
    if (!sesionGuardada) { window.location.href = 'views/login.html'; return; }

    const usuario = JSON.parse(sesionGuardada);

    // Redirigir si el usuario no es administrador
    if (usuario.rol !== 'admin') { window.location.href = 'app.html'; return; }

    document.getElementById('sidebar-nombre').textContent = usuario.nombre;

    document.querySelectorAll('.nav-item').forEach(elemento => {
        elemento.addEventListener('click', () => navigateAdmin(elemento.dataset.view));
    });

    const hashActual = location.hash.replace('#', '');
    navigateAdmin(vistasAdmin[hashActual] ? hashActual : 'admin_usuarios');
});

// SECCIÓN: USUARIOS

// Carga y pinta la tabla de usuarios registrados
async function initAdminUsuarios() {
    const datos       = await Api.get('admin_usuarios.php', { action: 'getUsuarios' });
    const cuerpoTabla = document.getElementById('tbody-usuarios');
    if (!cuerpoTabla) return;

    if (!datos.ok || !datos.usuarios.length) {
        cuerpoTabla.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-dim)">No hay usuarios.</td></tr>';
        return;
    }

    cuerpoTabla.innerHTML = datos.usuarios.map(usuario => {
        const fecha   = new Date(usuario.created_at).toLocaleDateString('es-ES', { day:'2-digit', month:'short', year:'numeric' });
        const esAdmin = usuario.rol === 'admin';
        return `<tr>
            <td style="text-align:left;color:var(--text-primary)">${usuario.nombre} ${usuario.apellidos}</td>
            <td>${usuario.email}</td>
            <td class="td-lime">${usuario.nivel_nombre || '-'}</td>
            <td>${usuario.objetivo}</td>
            <td>${usuario.dias_entreno}</td>
            <td><span class="tag ${esAdmin ? 'tag-admin' : 'tag-usuario'}">${usuario.rol}</span></td>
            <td>${fecha}</td>
            <td>${esAdmin ? '-' : `<button class="btn-borrar" onclick="borrarUsuario(${usuario.id}, '${usuario.nombre}')">Borrar</button>`}</td>
        </tr>`;
    }).join('');
}

// Elimina un usuario tras confirmación
async function borrarUsuario(id, nombre) {
    if (!confirm('¿Borrar al usuario ' + nombre + '? Esta acción no se puede deshacer.')) return;

    const datos     = await Api.post('admin_usuarios.php', { action: 'borrarUsuario', id });
    const mensajeEl = document.getElementById('admin-msg');

    if (datos.ok) {
        mostrarMsgAdmin(mensajeEl, 'ok', 'Usuario ' + nombre + ' eliminado correctamente.');
        await initAdminUsuarios();
    } else {
        mostrarMsgAdmin(mensajeEl, 'error', datos.error);
    }
}

// SECCIÓN: MENSAJES DE CONTACTO

// Carga y pinta los mensajes del formulario de contacto
async function initAdminContacto() {
    const datos = await Api.get('admin_contacto.php', { action: 'getMensajes' });
    const lista = document.getElementById('mensajes-lista');
    if (!lista) return;

    if (!datos.ok || !datos.mensajes.length) {
        lista.innerHTML = '<div class="loader">No hay mensajes todavía.</div>';
        return;
    }

    lista.innerHTML = datos.mensajes.map(mensaje => {
        const fecha = new Date(mensaje.fecha).toLocaleDateString('es-ES', {
            day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit'
        });
        return `<div class="mensaje-card">
            <div class="mensaje-header">
                <div class="mensaje-meta">
                    <div class="mensaje-nombre">${mensaje.nombre}</div>
                    <div class="mensaje-email">${mensaje.email}</div>
                </div>
                <div style="display:flex;gap:8px;align-items:center">
                    <div class="mensaje-fecha">${fecha}</div>
                    <button class="btn-borrar" onclick="borrarMensaje(${mensaje.id})">Borrar</button>
                </div>
            </div>
            <div class="mensaje-asunto">${mensaje.asunto}</div>
            <div class="mensaje-texto">${mensaje.mensaje}</div>
        </div>`;
    }).join('');
}

// Elimina un mensaje tras confirmación
async function borrarMensaje(id) {
    if (!confirm('¿Borrar este mensaje?')) return;
    const datos = await Api.post('admin_contacto.php', { action: 'borrarMensaje', id });
    if (datos.ok) await initAdminContacto();
}

// SECCIÓN: PERFIL DEL ADMINISTRADOR

// Muestra los datos del administrador en su perfil
function initAdminPerfil() {
    const usuario      = JSON.parse(sessionStorage.getItem('bx_usuario'));
    const elementoNombre = document.getElementById('admin-perfil-nombre');
    const elementoEmail  = document.getElementById('admin-perfil-email');
    if (elementoNombre) elementoNombre.textContent = usuario.nombre + ' ' + usuario.apellidos;
    if (elementoEmail)  elementoEmail.textContent  = usuario.email;
}

// Cambia la contraseña del administrador
async function cambiarPasswordAdmin() {
    const usuario   = JSON.parse(sessionStorage.getItem('bx_usuario'));
    const actual    = document.getElementById('admin-pass-actual').value;
    const nueva     = document.getElementById('admin-pass-nueva').value;
    const confirmar = document.getElementById('admin-pass-confirmar').value;
    const mensajeEl = document.getElementById('admin-pass-msg');

    const datos = await Api.post('password.php', {
        action: 'cambiarPassword',
        id:     usuario.id,
        actual,
        nueva,
        confirmar
    });

    if (datos.ok) {
        mostrarMsgAdmin(mensajeEl, 'ok', 'Contraseña actualizada correctamente.');
        document.getElementById('admin-pass-actual').value    = '';
        document.getElementById('admin-pass-nueva').value     = '';
        document.getElementById('admin-pass-confirmar').value = '';
    } else {
        mostrarMsgAdmin(mensajeEl, 'error', datos.error);
    }
}

// Muestra un mensaje temporal de éxito o error en el panel admin
function mostrarMsgAdmin(elemento, tipo, texto) {
    if (!elemento) return;
    elemento.textContent = texto;
    elemento.className   = 'msg visible ' + (tipo === 'ok' ? 'msg-ok' : 'msg-error');
    setTimeout(() => elemento.classList.remove('visible'), 4000);
}
