
function initContacto() {
    const usuario = JSON.parse(sessionStorage.getItem('bx_usuario'));

    // Prerrellenar nombre y email con los datos del usuario registrado
    const campoNombre = document.getElementById('c-nombre');
    const campoEmail  = document.getElementById('c-email');

    if (campoNombre) campoNombre.value = usuario.nombre + ' ' + usuario.apellidos;
    if (campoEmail)  campoEmail.value  = usuario.email;

    // Asignar evento de envío al botón
    const botonEnviar = document.getElementById('btn-enviar');
    if (botonEnviar) botonEnviar.addEventListener('click', enviarContacto);
}

// Envía el mensaje del formulario a la API
async function enviarContacto() {
    const mensajeEl = document.getElementById('contacto-msg');
    const nombre    = document.getElementById('c-nombre').value.trim();
    const email     = document.getElementById('c-email').value.trim();
    const asunto    = document.getElementById('c-asunto').value.trim();
    const mensaje   = document.getElementById('c-mensaje').value.trim();

    if (!nombre || !email || !asunto || !mensaje) {
        mostrarMsgContacto(mensajeEl, 'error', 'Completa todos los campos.');
        return;
    }

    // Deshabilitar el botón mientras se envía para evitar doble envío
    const boton = document.getElementById('btn-enviar');
    boton.disabled    = true;
    boton.textContent = 'ENVIANDO...';

    const datos = await Api.post('contacto.php', {
        action: 'enviarContacto',
        nombre,
        email,
        asunto,
        mensaje
    });

    boton.disabled    = false;
    boton.textContent = 'ENVIAR MENSAJE';

    if (datos.ok) {
        mostrarMsgContacto(mensajeEl, 'ok', datos.msg);
        // Limpiar asunto y mensaje pero mantener nombre y email
        document.getElementById('c-asunto').value  = '';
        document.getElementById('c-mensaje').value = '';
    } else {
        mostrarMsgContacto(mensajeEl, 'error', datos.error);
    }
}

// Muestra un mensaje de confirmación o error
function mostrarMsgContacto(elemento, tipo, texto) {
    if (!elemento) return;
    elemento.textContent = texto;
    elemento.className   = 'msg visible ' + (tipo === 'ok' ? 'msg-ok' : 'msg-error');
    setTimeout(() => elemento.classList.remove('visible'), 5000);
}
