
async function initPerfil() {
    const usuario = JSON.parse(sessionStorage.getItem('bx_usuario'));

    // Cargar datos completos del perfil desde la API
    const datos = await Api.get('usuario.php', {
        action: 'getPerfil',
        id:     usuario.id
    });

    if (!datos.ok) return;

    pintarPerfil(datos.usuario);
    pintarCheckins(datos.checkins);

    // Asignar eventos a los botones del perfil
    document.getElementById('btn-guardar-perfil').addEventListener('click', guardarPerfil);
    document.getElementById('btn-guardar-pass').addEventListener('click', guardarContrasena);
    document.getElementById('btn-logout').addEventListener('click', handleLogout);
    document.getElementById('input-foto').addEventListener('change', subirFoto);

    // Mostrar u ocultar el bloque de cambio de contraseña
    document.getElementById('btn-toggle-pass').addEventListener('click', () => {
        const bloque = document.getElementById('pass-block');
        bloque.style.display = bloque.style.display === 'none' ? 'block' : 'none';
    });
}

// Pinta los datos del usuario en la vista de perfil
function pintarPerfil(usuario) {
    // Mostrar foto o iniciales en el avatar
    const avatarEl = document.getElementById('perfil-avatar');
    if (usuario.foto) {
        avatarEl.innerHTML = `<img src="${usuario.foto}" alt="avatar">`;
    } else {
        const iniciales = (usuario.nombre[0] + (usuario.apellidos ? usuario.apellidos[0] : '')).toUpperCase();
        avatarEl.textContent = iniciales;
    }

    // Datos básicos del usuario
    document.getElementById('perfil-nombre').textContent       = usuario.nombre + ' ' + usuario.apellidos;
    document.getElementById('perfil-email').textContent        = usuario.email;
    document.getElementById('perfil-nivel-tag').textContent    = (usuario.nivel_nombre || 'Iniciado') + ' · Niv. ' + usuario.nivel_id;
    document.getElementById('perfil-objetivo-tag').textContent = usuario.objetivo;

    // Calcular y mostrar el IMC actual
    const alturaEnMetros = usuario.altura / 100;
    const imc            = (usuario.peso / (alturaEnMetros * alturaEnMetros)).toFixed(1);
    document.getElementById('perfil-imc').textContent     = imc;
    document.getElementById('perfil-imc-cat').textContent = categoriaIMC(parseFloat(imc));

    // Rellenar los campos editables con los datos actuales
    document.getElementById('edit-peso').value     = usuario.peso;
    document.getElementById('edit-altura').value   = usuario.altura;
    document.getElementById('edit-edad').value     = usuario.edad;
    document.getElementById('edit-dias').value     = usuario.dias_entreno;
    document.getElementById('edit-objetivo').value = usuario.objetivo;

    // Actualizar el sidebar con los nuevos datos
    actualizarSidebar(usuario);
}

// Pinta la tabla del historial de check-ins
function pintarCheckins(checkins) {
    const cuerpoTabla = document.getElementById('checkins-body');
    if (!checkins.length) {
        cuerpoTabla.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--text-dim)">Sin registros aún.</td></tr>`;
        return;
    }

    cuerpoTabla.innerHTML = checkins.map((checkin, indice) => {
        // Comparar con el registro anterior para calcular la variación
        const anterior  = checkins[indice + 1];
        let variacion   = '<span class="td-muted">— inicio</span>';

        if (anterior) {
            const diferencia = (parseFloat(checkin.peso) - parseFloat(anterior.peso)).toFixed(1);
            if (diferencia < 0) {
                variacion = `<span class="td-green">▼ ${diferencia} kg</span>`;
            } else if (diferencia > 0) {
                variacion = `<span class="td-red">▲ +${diferencia} kg</span>`;
            } else {
                variacion = `<span class="td-muted">= sin cambio</span>`;
            }
        }

        const fecha      = new Date(checkin.fecha).toLocaleDateString('es-ES', {
            day: '2-digit', month: 'short', year: 'numeric'
        });
        const colorNivel = colorPorNivel(checkin.nivel_id);

        return `
        <tr>
            <td>${fecha}</td>
            <td class="td-white">${checkin.peso} kg</td>
            <td class="td-white">${checkin.imc}</td>
            <td>${variacion}</td>
            <td style="color:${colorNivel}">${checkin.nivel_nombre || '—'}</td>
        </tr>`;
    }).join('');
}

// Guarda los cambios de datos físicos del usuario
async function guardarPerfil() {
    const usuario   = JSON.parse(sessionStorage.getItem('bx_usuario'));
    const mensajeEl = document.getElementById('perfil-msg');

    const peso    = document.getElementById('edit-peso').value;
    const altura  = document.getElementById('edit-altura').value;
    const edad    = document.getElementById('edit-edad').value;
    const dias    = document.getElementById('edit-dias').value;
    const objetivo = document.getElementById('edit-objetivo').value;

    if (!peso || !altura || !edad) {
        mostrarMsg(mensajeEl, 'error', 'Completa todos los campos.');
        return;
    }

    const datos = await Api.post('usuario.php', {
        action:       'updatePerfil',
        id:           usuario.id,
        peso,
        altura,
        edad,
        dias_entreno: dias,
        objetivo
    });

    if (datos.ok) {
        // Actualizar la sesión con los nuevos datos del usuario
        sessionStorage.setItem('bx_usuario', JSON.stringify(datos.usuario));
        pintarPerfil(datos.usuario);
        mostrarMsg(mensajeEl, 'ok', 'Cambios guardados correctamente.');

        // Recargar el historial de check-ins para mostrar el nuevo registro
        const checkins = await Api.get('usuario.php', {
            action: 'getPerfil',
            id:     datos.usuario.id
        });
        if (checkins.ok) pintarCheckins(checkins.checkins);
    } else {
        mostrarMsg(mensajeEl, 'error', datos.error);
    }
}

// Cambia la contraseña del usuario
async function guardarContrasena() {
    const usuario   = JSON.parse(sessionStorage.getItem('bx_usuario'));
    const mensajeEl = document.getElementById('pass-msg');

    const actual    = document.getElementById('pass-actual').value;
    const nueva     = document.getElementById('pass-nueva').value;
    const confirmar = document.getElementById('pass-confirmar').value;

    const datos = await Api.post('password.php', {
        action:    'cambiarPassword',
        id:        usuario.id,
        actual,
        nueva,
        confirmar
    });

    if (datos.ok) {
        mostrarMsg(mensajeEl, 'ok', datos.msg);
        document.getElementById('pass-actual').value    = '';
        document.getElementById('pass-nueva').value     = '';
        document.getElementById('pass-confirmar').value = '';
    } else {
        mostrarMsg(mensajeEl, 'error', datos.error);
    }
}

// Sube la foto de perfil al servidor
async function subirFoto(evento) {
    const usuario = JSON.parse(sessionStorage.getItem('bx_usuario'));
    const archivo = evento.target.files[0];
    if (!archivo) return;

    // FormData para enviar el archivo binario al servidor
    const formulario = new FormData();
    formulario.append('action', 'subirFoto');
    formulario.append('id', usuario.id);
    formulario.append('foto', archivo);

    try {
        const respuesta = await fetch('api/usuario.php', { method: 'POST', body: formulario });
        const datos     = await respuesta.json();

        if (datos.ok) {
            // Actualizar el avatar en pantalla, sidebar y sessionStorage
            const avatarEl = document.getElementById('perfil-avatar');
            avatarEl.innerHTML = `<img src="${datos.foto}" alt="avatar">`;

            const avatarSidebar = document.getElementById('sidebar-avatar');
            if (avatarSidebar) avatarSidebar.innerHTML = `<img src="${datos.foto}" alt="avatar">`;

            usuario.foto = datos.foto;
            sessionStorage.setItem('bx_usuario', JSON.stringify(usuario));
        }
    } catch (error) {
        console.error('Error al subir la foto:', error);
    }
}

// Actualiza el sidebar con los nuevos datos del usuario
function actualizarSidebar(usuario) {
    const iniciales = (usuario.nombre[0] + (usuario.apellidos ? usuario.apellidos[0] : '')).toUpperCase();
    const avatarEl  = document.getElementById('sidebar-avatar');

    if (avatarEl) {
        if (usuario.foto) {
            avatarEl.innerHTML = `<img src="${usuario.foto}" alt="avatar">`;
        } else {
            avatarEl.textContent = iniciales;
        }
    }

    const elementoNombre = document.getElementById('sidebar-nombre');
    const elementoNivel  = document.getElementById('sidebar-nivel');
    if (elementoNombre) elementoNombre.textContent = usuario.nombre + ' ' + usuario.apellidos[0] + '.';
    if (elementoNivel)  elementoNivel.textContent  = (usuario.nivel_nombre || 'Iniciado') + ' · Niv.' + usuario.nivel_id;
}

// Muestra un mensaje temporal de éxito o error
function mostrarMsg(elemento, tipo, texto) {
    if (!elemento) return;
    elemento.textContent = texto;
    elemento.className   = 'msg visible ' + (tipo === 'ok' ? 'msg-ok' : 'msg-error');
    setTimeout(() => elemento.classList.remove('visible'), 4000);
}

// Devuelve la categoría del IMC en texto
function categoriaIMC(imc) {
    if (imc < 18.5) return 'Bajo peso';
    if (imc < 25)   return 'Normal';
    if (imc < 30)   return 'Sobrepeso';
    return 'Obesidad';
}

// Devuelve el color correspondiente a cada nivel
function colorPorNivel(id) {
    const colores = { 1: '#888', 2: '#5b8fd4', 3: '#7ec453', 4: '#c8f135', 5: '#9b6fd4' };
    return colores[id] || '#555';
}
