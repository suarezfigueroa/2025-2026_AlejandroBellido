

// Mapa de vistas y sus funciones de inicio
const vistasDisponibles = {
    rutinas:  () => initRutinas(),
    dieta:    () => initDieta(),
    niveles:  () => initNiveles(),
    perfil:   () => initPerfil(),
    contacto: () => initContacto()
};

// Vista que se carga por defecto al entrar
const VISTA_DEFECTO = 'rutinas';

// Navega a una vista cargando su HTML e iniciando su módulo JS
async function navigate(vista) {
    if (!vistasDisponibles[vista]) return;

    // Marcar el elemento activo en el menú lateral
    document.querySelectorAll('.nav-item').forEach(elemento => {
        elemento.classList.toggle('active', elemento.dataset.view === vista);
    });

    // Mostrar indicador de carga mientras se obtiene la vista
    const contenedor = document.getElementById('view');
    contenedor.innerHTML = '<div class="loader">Cargando...</div>';

    // Cargar el HTML de la vista desde el servidor
    try {
        const respuesta = await fetch('views/' + vista + '.html');
        const html      = await respuesta.text();
        contenedor.innerHTML = html;
    } catch (error) {
        contenedor.innerHTML = '<div class="loader">Error al cargar la vista.</div>';
        return;
    }

    // Ejecutar la función de inicio del módulo correspondiente
    vistasDisponibles[vista]();

    // Guardar la vista actual en el hash de la URL
    location.hash = vista;
}

// Inicializa el sidebar con los datos del usuario
function initSidebar(usuario) {
    const iniciales = (usuario.nombre[0] + (usuario.apellidos ? usuario.apellidos[0] : '')).toUpperCase();

    const avatarEl = document.getElementById('sidebar-avatar');
    if (usuario.foto) {
        avatarEl.innerHTML = `<img src="${usuario.foto}" alt="foto">`;
    } else {
        avatarEl.textContent = iniciales;
    }

    document.getElementById('sidebar-nombre').textContent =
        usuario.nombre + ' ' + (usuario.apellidos ? usuario.apellidos[0] + '.' : '');

    document.getElementById('sidebar-nivel').textContent =
        (usuario.nivel_nombre || 'Nivel 1') + ' · Niv.' + (usuario.nivel_id || 1);
}

// Punto de arranque cuando el DOM está listo
document.addEventListener('DOMContentLoaded', () => {

    // Comprobar si hay sesión activa
    const sesionGuardada = sessionStorage.getItem('bx_usuario');
    if (!sesionGuardada) {
        window.location.href = 'views/login.html';
        return;
    }

    const usuario = JSON.parse(sesionGuardada);

    // Inicializar el sidebar con los datos del usuario
    initSidebar(usuario);

    // Asignar eventos de clic al menú lateral
    document.querySelectorAll('.nav-item').forEach(elemento => {
        elemento.addEventListener('click', () => navigate(elemento.dataset.view));
    });

    // Cargar la vista del hash actual o la vista por defecto
    const hashActual = location.hash.replace('#', '');
    navigate(vistasDisponibles[hashActual] ? hashActual : VISTA_DEFECTO);
});
