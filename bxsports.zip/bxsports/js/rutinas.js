
// Mapa de días según la frecuencia de entrenamiento del usuario
const MAPA_DIAS = {
    '1-2': [
        { key: 'Lun', label: 'LUN', grupo: 'Full Body' },
        { key: 'Jue', label: 'JUE', grupo: 'Full Body' }
    ],
    '3-4': [
        { key: 'Lun', label: 'LUN', grupo: 'Push' },
        { key: 'Mar', label: 'MAR', grupo: 'Pull' },
        { key: 'Jue', label: 'JUE', grupo: 'Piernas' },
        { key: 'Vie', label: 'VIE', grupo: 'Full Body' }
    ],
    '5-6': [
        { key: 'Lun', label: 'LUN', grupo: 'Push' },
        { key: 'Mar', label: 'MAR', grupo: 'Pull' },
        { key: 'Mie', label: 'MIÉ', grupo: 'Piernas' },
        { key: 'Jue', label: 'JUE', grupo: 'Push' },
        { key: 'Vie', label: 'VIE', grupo: 'Pull' },
        { key: 'Sab', label: 'SÁB', grupo: 'Piernas' }
    ],
    '7': [
        { key: 'Lun', label: 'LUN', grupo: 'Push' },
        { key: 'Mar', label: 'MAR', grupo: 'Pull' },
        { key: 'Mie', label: 'MIÉ', grupo: 'Piernas' },
        { key: 'Jue', label: 'JUE', grupo: 'Push' },
        { key: 'Vie', label: 'VIE', grupo: 'Pull' },
        { key: 'Sab', label: 'SÁB', grupo: 'Piernas' },
        { key: 'Dom', label: 'DOM', grupo: 'Full Body' }
    ]
};

let diaSeleccionado   = '';
let categoriaActual   = 'Todos';
let diasDelUsuario    = [];
let nivelDelUsuario   = 1;

// Inicializa la vista de rutinas
async function initRutinas() {
    const usuario      = JSON.parse(sessionStorage.getItem('bx_usuario'));
    nivelDelUsuario    = usuario.nivel_id;
    diasDelUsuario     = MAPA_DIAS[usuario.dias_entreno] || MAPA_DIAS['3-4'];

    // Mostrar subtítulo con nivel, objetivo y días
    const subtitulo = document.getElementById('rutinas-sub');
    if (subtitulo) subtitulo.textContent = `Nivel ${usuario.nivel_nombre || 'Iniciado'} · ${usuario.objetivo} · ${usuario.dias_entreno} días/semana`;

    // Seleccionar el día de hoy si está en la rutina, si no el primero
    const hoy           = ['Dom','Lun','Mar','Mie','Jue','Vie','Sab'][new Date().getDay()];
    const hayDiaDeHoy   = diasDelUsuario.find(d => d.key === hoy);
    diaSeleccionado     = hayDiaDeHoy ? hoy : diasDelUsuario[0].key;

    pintarPestanasDias();
    asignarFiltros();
    await cargarEjercicios();
}

// Pinta las pestañas de días en el HTML
function pintarPestanasDias() {
    const contenedorPestanas = document.getElementById('dias-tabs');
    if (!contenedorPestanas) return;

    contenedorPestanas.innerHTML = diasDelUsuario.map(dia => `
        <button class="dia-tab ${dia.key === diaSeleccionado ? 'active' : ''}" data-dia="${dia.key}" data-grupo="${dia.grupo}">
            ${dia.label}
            <span class="dia-tab-grupo">${dia.grupo}</span>
        </button>
    `).join('');

    // Evento de clic en cada pestaña
    contenedorPestanas.querySelectorAll('.dia-tab').forEach(boton => {
        boton.addEventListener('click', async () => {
            contenedorPestanas.querySelectorAll('.dia-tab').forEach(b => b.classList.remove('active'));
            boton.classList.add('active');
            diaSeleccionado = boton.dataset.dia;
            actualizarGrupoMuscular(boton.dataset.grupo);
            await cargarEjercicios();
        });
    });

    // Mostrar el grupo del día activo al cargar
    const diaActivo = diasDelUsuario.find(d => d.key === diaSeleccionado);
    if (diaActivo) actualizarGrupoMuscular(diaActivo.grupo);
}

// Actualiza el indicador de grupo muscular del día
function actualizarGrupoMuscular(grupo) {
    const indicador = document.getElementById('dia-grupo');
    if (!indicador) return;

    const coloresPorGrupo = {
        'Push':      'var(--lime)',
        'Pull':      'var(--blue)',
        'Piernas':   'var(--green)',
        'Full Body': 'var(--text-secondary)'
    };

    indicador.innerHTML = `<span style="color:${coloresPorGrupo[grupo] || '#fff'}">● ${grupo.toUpperCase()}</span>`;
}

// Asigna los eventos de clic a los botones de filtro por categoría
function asignarFiltros() {
    document.querySelectorAll('.filtro-btn').forEach(boton => {
        boton.addEventListener('click', async () => {
            document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('active'));
            boton.classList.add('active');
            categoriaActual = boton.dataset.cat;
            await cargarEjercicios();
        });
    });
}

// Carga los ejercicios desde la API según nivel, día y categoría
async function cargarEjercicios() {
    const grid = document.getElementById('rutinas-grid');
    if (!grid) return;

    grid.innerHTML = '<div class="loader">Cargando ejercicios...</div>';

    const datos = await Api.get('rutinas.php', {
        action:    'getEjercicios',
        nivel_id:  nivelDelUsuario,
        dia:       diaSeleccionado,
        categoria: categoriaActual
    });

    if (!datos.ok || !datos.ejercicios.length) {
        grid.innerHTML = '<div class="loader">No hay ejercicios para este día.</div>';
        return;
    }

    // Pintar las cards y asignar eventos de clic
    grid.innerHTML = datos.ejercicios.map(ejercicio => tarjetaEjercicio(ejercicio)).join('');

    grid.querySelectorAll('.ejercicio-card').forEach(tarjeta => {
        tarjeta.addEventListener('click', () => abrirModal(tarjeta.dataset.id));
    });
}

// Genera el HTML de una tarjeta de ejercicio
function tarjetaEjercicio(ejercicio) {
    const claseCategoria = ejercicio.categoria.toLowerCase().replace('é', 'e');
    const imagenHtml     = ejercicio.imagen
        ? `<img src="${ejercicio.imagen}" alt="${ejercicio.nombre}">`
        : `<span>SIN FOTO</span>`;

    return `
    <div class="ejercicio-card" data-id="${ejercicio.id}">
        <div class="ejercicio-img">${imagenHtml}</div>
        <div class="ejercicio-body">
            <div class="ejercicio-nombre">${ejercicio.nombre}</div>
            <div class="ejercicio-cat ${claseCategoria}">${ejercicio.categoria.toUpperCase()}</div>
            <div class="ejercicio-meta">${ejercicio.series}×${ejercicio.repeticiones} · ${ejercicio.descanso}s</div>
        </div>
    </div>`;
}

// Abre el modal con el detalle del ejercicio
async function abrirModal(id) {
    const overlay  = document.getElementById('modal-overlay');
    const contenido = document.getElementById('modal-content');
    if (!overlay || !contenido) return;

    contenido.innerHTML = '<div class="loader">Cargando...</div>';
    overlay.classList.add('visible');

    const datos = await Api.get('rutinas.php', { action: 'getEjercicio', id });
    if (!datos.ok) {
        contenido.innerHTML = '<div class="loader">Error al cargar.</div>';
        return;
    }

    const ejercicio      = datos.ejercicio;
    const claseCategoria = ejercicio.categoria.toLowerCase().replace('é', 'e');
    const imagenHtml     = ejercicio.imagen
        ? `<img src="${ejercicio.imagen}" alt="${ejercicio.nombre}">`
        : `<span>SIN FOTO</span>`;

    contenido.innerHTML = `
        <div class="modal-img">${imagenHtml}</div>
        <div class="modal-nombre">${ejercicio.nombre}</div>
        <div class="modal-nivel">
            <span class="ejercicio-cat ${claseCategoria}">${ejercicio.categoria.toUpperCase()}</span>
            · ${ejercicio.nivel_nombre}
            · <span style="color:var(--text-muted)">${ejercicio.grupo_muscular}</span>
        </div>
        <div class="modal-desc">${ejercicio.descripcion}</div>
        <div class="modal-stats">
            <div class="modal-stat">
                <div class="modal-stat-label">SERIES</div>
                <div class="modal-stat-val">${ejercicio.series}</div>
            </div>
            <div class="modal-stat">
                <div class="modal-stat-label">REPS</div>
                <div class="modal-stat-val">${ejercicio.repeticiones}</div>
            </div>
            <div class="modal-stat">
                <div class="modal-stat-label">DESCANSO</div>
                <div class="modal-stat-val">${ejercicio.descanso}s</div>
            </div>
        </div>
    `;
}

// Cierra el modal de detalle
function cerrarModal() {
    const overlay = document.getElementById('modal-overlay');
    if (overlay) overlay.classList.remove('visible');
}
